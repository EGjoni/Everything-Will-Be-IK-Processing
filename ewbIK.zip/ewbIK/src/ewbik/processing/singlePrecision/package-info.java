/**
 * 
 */
/**
 * @author Eron Gjoni
 *
 */
package ewbik.processing.singlePrecision;